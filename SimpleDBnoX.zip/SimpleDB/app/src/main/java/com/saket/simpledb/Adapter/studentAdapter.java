package com.saket.simpledb.Adapter;


import com.saket.simpledb.Model.Students;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class studentAdapter
        extends RecyclerView.Adapter<studentAdapter.StudentViewHolder> {

    private final ArrayList<Students> studenList;

    private final studentOnClickListener onClickListener;


    studentAdapter(ArrayList<Students> trains, studentOnClickListener onClickListener) {

        this. = trains;
        this.onClickListener = onClickListener;
    }


    @NonNull
    @NotNull
    @Override
    public StudentViewHolder onCreateViewHolder(@NonNull @NotNull ViewGroup parent,
                                                    int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        return new SearchTrainViewHolder(
                layoutInflater.inflate(R.layout.item_search_train, parent, false));
    }


    @Override
    public void onBindViewHolder(@NonNull @NotNull SearchTrainViewHolder holder, int position) {

        TrainModel train = trains.get(position);

        holder.trainNumber.setText(String.valueOf(train.getNumber()));
        holder.trainName.setText(train.getName());
        holder.source.setText(train.getSource().replace("_", " "));
        holder.destination.setText(train.getDestination().replace("_", " "));

        SimpleDateFormat sdf = new SimpleDateFormat("MMM dd, yyyy", Locale.getDefault());

        String deptTime = sdf.format(new Date(train.getDepartureDate())) + " " + train
                .getDepartureTime();
        holder.deptTime.setText(deptTime);

        String arrTime = sdf.format(new Date(train.getArrivalDate())) + " " + train
                .getArrivalTime();
        holder.arrTime.setText(arrTime);

        holder.itemView.setOnClickListener(v -> {
            onClickListener.bookTrain(position);
        });

    }


    @Override
    public int getItemCount() {

        return trains.size();
    }


    public interface SearchTrainOnClickListener {

        void bookTrain(int position);

    }


    static class StudentViewHolder extends RecyclerView.ViewHolder {

        TextView trainNumber, trainName, source, destination, deptTime, arrTime;


        public StudentViewHolder(@NonNull @NotNull View itemView) {

            super(itemView);

            trainNumber = itemView.findViewById(R.id.tv_train_number);
            trainName = itemView.findViewById(R.id.tv_train_name);
            source = itemView.findViewById(R.id.tv_train_source);
            destination = itemView.findViewById(R.id.tv_train_destination);
            deptTime = itemView.findViewById(R.id.tv_train_departure_time);
            arrTime = itemView.findViewById(R.id.tv_train_arrival_time);

        }

    }

}